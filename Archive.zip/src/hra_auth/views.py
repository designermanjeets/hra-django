from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse
from django.shortcuts import render
from django.http import HttpResponse
from django.contrib.auth import authenticate, login, logout
from django.views.decorators.csrf import csrf_exempt
import jwt
from datetime import datetime, timedelta


# Secret key for JWT
SECRET_KEY = 'your_secret_key'

# Token expiration time
TOKEN_EXPIRATION_TIME = 15  # minutes

# Refresh token expiration time
REFRESH_TOKEN_EXPIRATION_TIME = 7  # days

@csrf_exempt
def login_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        # Authenticate user
        user = authenticate(request, username=username, password=password)

        if user is not None:
            # Generate access token
            access_token = generate_access_token(user)

            # Generate refresh token
            refresh_token = generate_refresh_token(user)

            # Set access token and refresh token as cookies
            response = HttpResponse()
            response.set_cookie('access_token', access_token, httponly=True)
            response.set_cookie('refresh_token', refresh_token, httponly=True)

            return response
        else:
            return HttpResponse('Invalid credentials', status=401)
    else:
        return HttpResponse('Method not allowed', status=405)

@csrf_exempt
def forget_password_view(request):
    if request.method == 'POST':
        # Logic for resetting password
        return HttpResponse('Password reset successful')
    else:
        return HttpResponse('Method not allowed', status=405)

@csrf_exempt
def signup_view(request):
    if request.method == 'POST':
        # Logic for user registration
        return HttpResponse('User registered successfully')
    else:
        return HttpResponse('Method not allowed', status=405)

def generate_access_token(user):
    # Set token expiration time
    expiration_time = datetime.utcnow() + timedelta(minutes=TOKEN_EXPIRATION_TIME)

    # Create payload for access token
    payload = {
        'user_id': user.id,
        'exp': expiration_time
    }

    # Generate access token
    access_token = jwt.encode(payload, SECRET_KEY, algorithm='HS256')

    return access_token

def generate_refresh_token(user):
    # Set token expiration time
    expiration_time = datetime.utcnow() + timedelta(days=REFRESH_TOKEN_EXPIRATION_TIME)

    # Create payload for refresh token
    payload = {
        'user_id': user.id,
        'exp': expiration_time
    }

    # Generate refresh token
    refresh_token = jwt.encode(payload, SECRET_KEY, algorithm='HS256')

    return refresh_token