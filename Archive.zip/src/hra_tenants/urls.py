from django.urls import path
from . import views

urlpatterns = [
    path('tenants/', views.tenants_view),
    path('tenants/<int:id>/', views.tenant_view),
    path('tenants/<int:id>/update/', views.update_tenant_view),
    path('tenants/<int:id>/delete/', views.delete_tenant_view),
    path('tenants/create/', views.create_tenant_view),
]